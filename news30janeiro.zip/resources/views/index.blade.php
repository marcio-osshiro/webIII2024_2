@extends('layouts.modelo')

@section('conteudo')
    <h1>Sistemas de Notícias</h1>
    <p>Este site foi construido na disciplina de Construção de Páginas Web III do Curso Superior de Tecnologias em Sistemas para Internet no ano de 2024 Segundo Semestre</p>
@endsection
