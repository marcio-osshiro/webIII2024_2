<?php $__env->startSection('conteudo'); ?>
    <h1>Noticias</h1>
    <a href="noticia/novo" class="btn btn-primary">Nova Notícia</a>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Título</th>
            <th scope="col">Data</th>
            <th scope="col">Autor</th>
            <th scope="col">Categoria</th>
            <th scope="col"></th>

            <th>Apagar</th>
            <th>Editar</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope='row'><?php echo e($noticia->id); ?></th>
                    <td><?php echo e($noticia->titulo); ?></td>
                    <td><?php echo e($noticia->data->format('d/m/Y')); ?></td>
                    <td><?php echo e($noticia->autor); ?></td>
                    <td><?php echo e($noticia->categoria->descricao); ?></td>
                    <td>
                        <?php if($noticia->imagem): ?>
                            <img src="/storage/imagens/<?php echo e($noticia->imagem); ?>" style="width:50px;">
                        <?php endif; ?>
                    </td>
                    <td>
                    <a class='btn btn-danger' href='noticia/apagar/<?php echo e($noticia->id); ?>'>x</a></td>
                    <td>
                    <a class='btn btn-primary' href='noticia/editar/<?php echo e($noticia->id); ?>'>+</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/listagemNoticia.blade.php ENDPATH**/ ?>