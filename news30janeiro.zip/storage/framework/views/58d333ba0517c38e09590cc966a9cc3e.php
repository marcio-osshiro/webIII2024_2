<?php $__env->startSection('conteudo'); ?>

        <h1>Usuário</h1>
        <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">E-mail</th>
                <th scope="col">Mensagem</th>
              </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope='row'><?php echo e($usuario->id); ?></th>
                      <td><?php echo e($usuario->name); ?></td>
                      <td><?php echo e($usuario->email); ?></td>
                      <td><a href="/usuario/mensagem/<?php echo e($usuario->id); ?>" class="btn btn-primary">Mensagem</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/listagemUsuario.blade.php ENDPATH**/ ?>