<?php $__env->startSection('conteudo'); ?>
<?php if(isset($mensagem)): ?>
            <div class='alert alert-primary' >nova mensagem: <?php echo e($mensagem); ?></div>
        <?php endif; ?>

        <h1>Categorias</h1>
        <a href="categoria/novo" class="btn btn-primary">Nova Categoria</a>
        <a href="categoria/pdf" class="btn btn-primary">Listagem</a>
        <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Descrição</th>
                <th scope="col"></th>
                <th>Apagar</th>
                <th>Editar</th>
              </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope='row'><?php echo e($categoria->id); ?></th>
                      <td><?php echo e($categoria->descricao); ?></td>
                      <td>
                        <?php if($categoria->imagem): ?>
                            <img src="/storage/imagens/<?php echo e($categoria->imagem); ?>" style="width:50px;">
                        <?php endif; ?>
                      </td>
                      <td>
                      <a class='btn btn-danger' href='categoria/apagar/<?php echo e($categoria->id); ?>'>x</a></td>
                      <td>
                      <a class='btn btn-primary' href='categoria/editar/<?php echo e($categoria->id); ?>'>+</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/listagemCategoria.blade.php ENDPATH**/ ?>