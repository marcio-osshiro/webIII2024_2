<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      body {
        width: 100%;
        padding: 2rem;
      }
      h1 {
        text-align: center;
        font-size: 3rem;
      }
      table {
        width: 80%;
        margin: auto;
        border-collapse: collapse;
      }
      td, th {
        border: 1px solid black;
        padding: 0.25rem;
        font-size: 1.5rem;
      }
    </style>
</head>
<body>
    <h1>Categorias</h1>
    <table>
        <thead>
            <tr>
            <th>#</th>
            <th>Descrição</th>
            <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($categoria->id); ?></th>
                    <td><?php echo e($categoria->descricao); ?></td>
                    <td>
                    <?php if($categoria->imagem): ?>
                        <img src="<?php echo e(storage_path('app/public/imagens/'.$categoria->imagem)); ?>" style="width:50px;">
                    <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
</body>
</html>
<?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/listagemCategoriaPDF.blade.php ENDPATH**/ ?>