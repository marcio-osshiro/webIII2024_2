<?php $__env->startSection('conteudo'); ?>
    <h1>Mensagem para Usuário: <?php echo e($usuario->name); ?> (<?php echo e($usuario->email); ?>)</h1>

    <form action="<?php echo e(url('usuario/sendMail')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <input type="hidden" name="id" value='<?php echo e($usuario->id); ?>'>
            <label for="mensagem" class="form-label">Mensagem</label>
            <textarea name="mensagem" class="form-control" style="height: 10rem;width: 100%"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/formularioMensagem.blade.php ENDPATH**/ ?>