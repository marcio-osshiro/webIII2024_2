<?php $__env->startSection('conteudo'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <h1>Notícia</h1>
    <?php if($noticia->imagem): ?>
        <img src="/storage/imagens/<?php echo e($noticia->imagem); ?>" style="width:40%;">
    <?php endif; ?>

    <form action="<?php echo e(url('noticia/salvar')); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="id" class="form-label">ID</label>
            <input readonly type="text" class="form-control" id="id" name="id" value="<?php echo e($noticia->id); ?>">
        </div>
        <div class="mb-3">
            <label for="titulo" class="form-label">Título</label>
            <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo e(old('titulo', $noticia->titulo)); ?>">
        </div>
        <div class="mb-3">
            <label for="data" class="form-label">Data</label>
            <input type="date" class="form-control" id="data" name="data" value="<?php echo e(old('data', $noticia->data->format('Y-m-d'))); ?>">
        </div>
        <div class="mb-3">
            <label for="autor" class="form-label">Autor</label>
            <input type="text" class="form-control" id="autor" name="autor"  value="<?php echo e(old('autor', $noticia->autor)); ?>">
        </div>

        <div class="mb-3">
            <label for="categoria_id" class="form-label">Categoria</label>
            <select class="form-select" name="categoria_id" id="categoria_id">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($noticia->categoria == null || $categoria->id != old('categoria_id', $noticia->categoria->id) ? '' : 'selected'); ?> value='<?php echo e($categoria->id); ?>'><?php echo e($categoria->descricao); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <div class="mb-3">
            <label for="arquivo" class="form-label">Arquivo</label>
            <input type="file" class="form-control" id="arquivo" name="arquivo">
        </div>


        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/formularioNoticia.blade.php ENDPATH**/ ?>