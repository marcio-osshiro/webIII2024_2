<?php $__env->startSection('conteudo'); ?>
    <h1>Sistemas de Notícias</h1>
    <p>Este site foi construido na disciplina de Construção de Páginas Web III do Curso Superior de Tecnologias em Sistemas para Internet no ano de 2024 Segundo Semestre</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.modelo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aluno\Documents\webIII\news\resources\views/index.blade.php ENDPATH**/ ?>